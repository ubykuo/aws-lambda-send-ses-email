﻿"use strict";

var config = {
    "templateKey" : "templates/template.html",
    "targetAddress" : "info@ubykuo.com",
    "fromAddress": "Me <info@ubykuo.com>",
    "defaultSubject" : "Email From {{name}}"
}

module.exports = config
